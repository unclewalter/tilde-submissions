(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(3);

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__(4);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var crypto = __webpack_require__(5),
    fs = __webpack_require__(6),
    AWS = __webpack_require__(0);

var getFilesizeInBytes = function getFilesizeInBytes(filename) {
  var stats = fs.statSync(filename);
  var fileSizeInBytes = stats["size"];
  return fileSizeInBytes;
};

var removeEmptyStringElements = function removeEmptyStringElements(obj) {
  for (var prop in obj) {
    if ((0, _typeof3.default)(obj[prop]) === 'object') {
      // dive deeper in
      removeEmptyStringElements(obj[prop]);
    } else if (obj[prop] === '') {
      // delete elements that are empty strings
      delete obj[prop];
    }
  }
  return obj;
};

/*
Function Name: processSubmission

Process:
1. Receives Expression of Interest submission details.
2. Generates hash from email address.
3. Generates PDF file named <hash>-<timestamp>.pdf using the submission details
   - TODO: Possibly move this process into another module.
4. Concatinates CV from submission
5. Pushes the PDF file to S3.
*/

module.exports.processSubmission = function (submissionDetails, context) {
  var hash = crypto.createHash('md5').update(submissionDetails.email).digest("hex");
  var identifier = hash + '_' + submissionDetails.timestamp;
  var filename = identifier + '.pdf';

  if (submissionDetails.cv.fname) {
    var cvFileExt = submissionDetails.cv.fname.split('.').pop();
  }
  var cvfilename = identifier + '-cv.' + cvFileExt;

  var docClient = new AWS.DynamoDB.DocumentClient();

  var params = {
    TableName: "tilde-submissions",
    Item: removeEmptyStringElements(submissionDetails)
  };

  params.Item.submissionID = identifier;

  console.log("Adding a new item...");
  docClient.put(params, function (err, data) {
    if (err) {
      context.fail("Unable to add item. Error JSON: " + (0, _stringify2.default)(err, null, 2));
    } else {
      console.log("Added item:", (0, _stringify2.default)(data, null, 2));
    }
    var returnPayload = {
      cvfilename: cvfilename,
      message: err
    };
    context.succeed(returnPayload);
  });
};

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// // Loading Dependencies
var proc = __webpack_require__(1);
//     email  = require('./confirmation-email'),

var AWS = __webpack_require__(0);
// import uuid from 'uuid';
// import proc from './process-submission'

module.exports.main = function (evt, context, callback) {

  var event = evt.body;
  var datetime = new Date();
  var timestamp = datetime.getTime(); // Generate timestamp for server time

  console.log("Incoming: ", event);

  console.log("email address =", event.email);
  console.log("time stamp =", timestamp);

  if (!event.email) {
    context.fail("No email address provided");
  } else if (event.email != event.confirm_email) {
    context.fail("Email address and confirmation do not match!");
  }
  /*
  TODO: Add proper email validation
        Add responses for user feedback
  */

  var submissionDetails = {
    "timestamp": event.timestamp,
    "name": event.name,
    "email": event.email,
    "confirm_email": event.confirm_email,
    "phone_number": event.phone_number,
    "discipline": event.discipline,
    "artistBio": event.artistBio,
    "cv": event.cv,
    "project_title": event.project_title,
    "short_description": event.short_description,
    "long_description": event.long_description,
    "duration": event.duration,
    "technical_requirements": event.technical_requirements,
    "setup_time": event.setup_time,
    "instrumentation": event.instrumentation,
    "outsideOfAustralia": event.outsideOfAustralia,
    "soughtFunding": event.soughtFunding,
    "focus_areas": event.focus_areas,
    "links": event.links,
    "comments": event.comments
  };
  proc.processSubmission(submissionDetails, context);
  // const submissionID = uuid.v1();

  // const str = "submissionID: "+submissionID;
  // return callback(null, str);
};

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/typeof");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ })
/******/ ])));